//This assignment consists in implementing a double-linked list with fast accessing
//Student name - Sudarshana Sarma
import java.util.ArrayList;
import java.util.NoSuchElementException;

public class IDLList<E> {
	private static class Node<E> {
		E data;
		Node<E> next;
		Node<E> prev;
//prev is the reference to the previous node
//next is the reference to the next node		
// elem the element to be stored
		
		Node(E elem) {
			data = elem;
			prev = next = null;
		}

		Node(E elem, Node<E> prev, Node<E> next) {
			data = elem;
			this.prev = prev;
			this.next = next;
		}
	}

	private Node<E> head;
	private Node<E> tail;
	private int size;
	private ArrayList<Node<E>> indices;

	public IDLList() {
		//Creating dummy head and tail nodes
		head = new Node<>(null);
		tail = new Node<>(null);
		head.next = tail;
		tail.prev = head;
		size = 0;
		indices = new ArrayList<Node<E>>();
	}
// this method adds an element at a specified index	

	public boolean add(int index, E elem) throws IndexOutOfBoundsException {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException();
		} 
		
		Node<E> newNode = new Node<> (elem);
		Node<E> existing = size == index ? tail : indices.get(index);
		existing.prev.next = newNode;
		newNode.prev = existing.prev;
		existing.prev = newNode;
		newNode.next = existing;
		size++;
		indices.add(index, newNode);
		
		return true;
	}
//this method adds element at the head
	public boolean add(E elem) {
		return add(0, elem);
	}
//this method adds the element at the end of the list
	public boolean append(E elem) {
		return add(size, elem);
	}
//this method returns the object at position index
	public E get(int index) {
		if (size == 0) {
			throw new NoSuchElementException();
		}
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		}
		

		Node<E> tempNode = indices.get(index);
		return tempNode.data;
	}
//this method gets the first element of the list
	public E getHead() {
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return head.next.data;

	}
//this method gets the last element of the list
	public E getLast() {
		if (size == 0) {
			throw new NoSuchElementException();
		}
		return tail.prev.data;
	}
//this method gets the list size
	public int size() {
		return size;

	}
//this method removes the first object in the list
	public E remove() {
		
		if (size == 0) {
			throw new NoSuchElementException();
		}

		head.next = head.next.next;
		head.next.prev = head;

		size--;
		return indices.remove(0).data;
		
	}
// this method removes the last object in the list
	public E removeLast() {

		if (size == 0) {
			throw new NoSuchElementException();

		}

		E val = tail.prev.data;
		System.out.println("val: " + val);
		System.out.println(tail.prev.prev.data);
		tail.prev = tail.prev.prev;
		tail.prev.next = tail;
		size --;
		return val;

	}
// this method removes element at the specified index
	public E removeAt(int index) {
		if (index < 0 || index > size) {
			throw new IndexOutOfBoundsException();
		} else if (size == 0) {
			throw new NoSuchElementException();
		} else if (index == 0) {
			return remove();
		} else if (index == size) {
			return removeLast();
		}

		Node<E> tempNode = indices.remove(index);

		tempNode.next.prev = tempNode.prev;
		tempNode.prev.next = tempNode.next;
		size--;
		return tempNode.data;


	}
// this method removes the first occurence of the elem in the list
	public boolean remove(E elem) {
		if (size == 0) {
			throw new NoSuchElementException();
		}

		Node<E> temporarNode = head.next;
		int indexToBeRemoved = 0;
		for (int i = 0; i < size; i++) {
			if (temporarNode.data.equals(elem)) {
				removeAt(indexToBeRemoved);
				return true;
			}
			temporarNode = temporarNode.next;
			indexToBeRemoved++;
		}
		return false;
	}
// this method gives the string representation of the list
	public String toString() {
		String rep = "";
		Node<E> tempNode = head.next;
		while (tempNode != tail) {
			rep = rep + " " + tempNode.data;
			tempNode = tempNode.next;
		}
		return rep;

	}

}