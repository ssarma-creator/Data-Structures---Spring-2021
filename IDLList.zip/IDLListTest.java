
public class IDLListTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IDLList <String> id = new IDLList<>();
		
		
		try {
			id.add(-1, "w1");
			System.out.println("Index Out of Bounds Not Working");
		} catch (IndexOutOfBoundsException e){

		}
		try {
			id.add(1, "w1");
			System.out.println("Index within Bounds Not Working");
		} catch (IndexOutOfBoundsException e){
			
		}
		
		System.out.println(id.add("j1"));
		
		System.out.println(id.add(0, "j2"));
		
		System.out.println(id.append("data"));
		System.out.println(id.toString());
		System.out.println(id.get(0));
		System.out.println(id.add(2, "j3"));
		System.out.println(id.toString());
		System.out.println(id.add(3, "j4"));
		System.out.println(id.add(4, "j5"));
		System.out.println(id.add(5, "j6"));
		System.out.println(id.add(6, "j7"));
		System.out.println(id.add(7, "j8"));
		System.out.println(id.toString());
		System.out.println(id.getHead());
		System.out.println(id.getLast());
		System.out.println(id.remove());
		System.out.println(id.toString());
		System.out.println(id.removeLast());
		System.out.println(id.toString());
		System.out.println(id.removeAt(2));
		System.out.println(id.toString());
		System.out.println(id.size());
		System.out.println(id.remove("j5"));
		
	}

}