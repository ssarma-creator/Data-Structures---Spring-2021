package Maze;


public class PairInt {
	private int x;
	private int y;

	/*
	 * constructor to initialize the co-ordinate of maze
	 * 
	 * @param x the x-coordinate of the point
	 * 
	 * @param y the y-coordinate of the point
	 */
	public PairInt(int x, int y) {
		this.x = x;
		this.y = y;
	}

	// @return x-coordinate of the point
	public int getX() {
		return x;
	}

	// @return y-coordinate of the point
	public int getY() {
		return y;
	}

// set value of x-coordinate of point
	public void setX(int x) {
		this.x = x;
	}

	// set value of y-coordinate of point
	public void setY(int y) {
		this.y = y;
	}

	// compares object of PairInt
	public boolean equals(Object p) {
		PairInt res = (PairInt) p;
		if (this.x == res.x && this.y == res.y) {
			return true;
		} else {
			return false;
		}
	}

//String representation of points     
	public String toString() {
		return "(" + x + ", " + y + ")";
	}

//@return new copy of PairInt     
	public PairInt copy() {
		return new PairInt(x, y);

	}
}
